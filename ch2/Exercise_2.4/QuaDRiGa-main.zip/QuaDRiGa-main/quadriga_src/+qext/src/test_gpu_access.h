#ifndef test_gpu_access_H
#define test_gpu_access_H

void test_gpu_access_CUDA( double *cc );

#endif
