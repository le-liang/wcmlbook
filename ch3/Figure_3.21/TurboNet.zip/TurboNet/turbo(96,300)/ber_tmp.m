close all;
% clear;
clc;

SNR_vector = 0:0.5:2.5;
K = 40;
ber_map_vector = zeros(1,length(SNR_vector));
for snr_i = 1:1:length(SNR_vector)
    FN_BER_Log = ['BER_K' num2str(K) '_R_1_3_Log_Iter' num2str(18) '_SNR' num2str(SNR_vector(snr_i)) 'dB.csv'];
    ber_map_vector(1, snr_i) = csvread(FN_BER_Log);
%     FN_BER_Max = ['BER_K' num2str(K) '_R_1_3_Max_Iter' num2str(num_iter) '_SNR' num2str(SNR) 'dB.csv'];
end
semilogy(SNR_vector, ber_map_vector);