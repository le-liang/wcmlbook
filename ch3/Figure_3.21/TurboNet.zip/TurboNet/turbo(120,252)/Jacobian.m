function y = Jacobian(x1, x2)
y = log(1 + exp(-(abs(x1-x2))));