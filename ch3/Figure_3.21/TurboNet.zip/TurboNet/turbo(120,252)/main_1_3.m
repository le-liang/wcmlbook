clc;
clear;
K = 40;
modu_type = 'BPSK';
num_comm = 6e4;
num_test = 6e4;
num_train = num_comm - num_test;
num_iter = 3;
SNR = 4;
error_max = 0;
error_log = 0;
data_write_Y = zeros(num_comm, K);
data_write_X = zeros(num_comm, K*3+12);
data_write_LLR = zeros(num_comm, K); %
for i = 1:1:num_comm
    x_data_in = randi([0,1],1,K);
    data_write_Y(i,:) = x_data_in(1,:);
%     if i == 1
%         data_write_Y = x_data_in;
%     else
%         data_write_Y = [data_write_Y ; x_data_in];
%     end
    input_interleaver = turbo_interleaver(length(x_data_in));
    x_data_out=turbo_encode(x_data_in,length(x_data_in),input_interleaver);
    x_data_out_reshape = reshape(x_data_out,1,[]);
    tmp = zeros(1, 12);
    x_data_new = [x_data_out_reshape(1,1:1:120) tmp];
%     x_data_new = [x_data_out_reshape 0 0 0];
    mod = tx_modulate(x_data_new, modu_type);
%     bpskSym = x_data_out;
%     bpskSym(find(bpskSym<1))=-1;
    sigma = sqrt(1/(10^(SNR/10)));% the sigma of the Guassian function sigma^2 = No/2
    y = awgn(mod,SNR);
    demod_soft = demodulate_soft(y, modu_type);
    demod_soft_new = demod_soft(1, 1:1:length(demod_soft)-3);
    y_data_in = reshape(demod_soft_new, 3, []);
%     y_data_in(1,:) = awgn(bpskSym(1,:),SNR);
%     y_data_in(2,:) = awgn(bpskSym(2,:),SNR);
%     y_data_in(3,:) = awgn(bpskSym(3,:),SNR);
    demod = zeros(1, 3*K+12);
    for j = 1:1:K
        demod(1,3*j-2) = y_data_in(1,j);
        demod(1,3*j-1) = y_data_in(2,j);
        demod(1,3*j) = y_data_in(3,j);
    end
    demod(1,3*K+1) = y_data_in(1,K+1);
    demod(1,3*K+2) = y_data_in(2,K+1);
    demod(1,3*K+3) = y_data_in(1,K+2);
    demod(1,3*K+4) = y_data_in(2,K+2);
    demod(1,3*K+5) = y_data_in(1,K+3);
    demod(1,3*K+6) = y_data_in(2,K+3);
    demod(1,3*K+8) = y_data_in(3,K+1);
    demod(1,3*K+10) = y_data_in(3,K+2);
    demod(1,3*K+12) = y_data_in(3,K+3);
    data_write_X(i,:) = demod(1,:);
%     if i == 1
%         data_write_X = demod;
%     else
%         data_write_X = [data_write_X ; demod];
%     end
    [x_h_max, llr_temp_max] = turbo_decode_maxlogmap(num_iter,y_data_in,input_interleaver);
    [x_h_log, llr_temp_log] = turbo_decode_logmap(num_iter,y_data_in,input_interleaver);
    data_write_LLR(i,:) = llr_temp_log;%
    ber_temp_max = sum(abs(x_data_in- x_h_max));
    error_max = error_max + ber_temp_max;
    ber_temp_log = sum(abs(x_data_in- x_h_log));
    error_log = error_log + ber_temp_log;
end
ber_max = error_max / (num_comm * K);
ber_log = error_log / (num_comm * K);

filename_X_train = [num2str(num_iter) 'X_train_' num2str(SNR) 'dB(' num2str(num_train) ').csv'];
filename_Y_train = [num2str(num_iter) 'Y_train_' num2str(SNR) 'dB(' num2str(num_train) ').csv'];
filename_LLR_train = [num2str(num_iter) 'LLR_train_' num2str(SNR) 'dB(' num2str(num_train) ').csv'];%
filename_BER = [num2str(num_iter) 'map_' num2str(SNR) 'dB.csv'];
filename_X_test = [num2str(num_iter) 'X_test_' num2str(SNR) 'dB(' num2str(num_test) ').csv'];
filename_Y_test = [num2str(num_iter) 'Y_test_' num2str(SNR) 'dB(' num2str(num_test) ').csv'];
filename_BER_LogMAP = [num2str(num_iter) 'logmap_' num2str(SNR) 'dB(' num2str(num_train) ').csv'];
filename_demod = [num2str(num_iter) 'demo d_' num2str(SNR) 'dB(' num2str(num_train) ').csv'];
FN_BER_Log = ['BER_K' num2str(K) '_R_1_3_Log_Iter' num2str(num_iter) '_SNR' num2str(SNR) 'dB.csv'];
FN_BER_Max = ['BER_K' num2str(K) '_R_1_3_Max_Iter' num2str(num_iter) '_SNR' num2str(SNR) 'dB.csv'];
% csvwrite(FN_BER_Log, ber_log);
% csvwrite(FN_BER_Max, ber_max);
% csvwrite(filename_X_train, data_write_X(1:1:num_train,:));
% csvwrite(filename_Y_train, data_write_Y(1:1:num_train,:));
% csvwrite(filename_LLR_train, data_write_LLR(1:1:num_ train,:));
% csvwrite(filename_X_test, data_write_X(num_train+1:1:num_comm,:));
% csvwrite(filename_Y_test, data_write_Y(num_train+1:1:num_comm,:));
% csvwrite(filename_BER, ber_max);
% csvwrite(filename_BER_LogMAP, ber_log);
% csvwrite(filename_demod, y_data_in);

%3GPP��׼��֯��,�ɹ�ѡ��
% input_interleaver = randperm(length(x_data_in))-1;

% bpskSym = x_data_out;
% bpskSym(find(bpskSym<1))=-1;
 
% for SNR = -3:0.2:3;%10*log10(0.5); % SNR is in dB unit, for power ratio
% sigma = sqrt(1/(10^(SNR/10)));% the sigma of the Guassian function sigma^2 = No/2
% y_data_in(1,:) = awgn(bpskSym(1,:),SNR);
% y_data_in(2,:) = awgn(bpskSym(2,:),SNR);
% y_data_in(3,:)= awgn(bpskSym(3,:),SNR);
% iterNum=6;
% x_h = turbo_decode(iterNum,y_data_in,input_interleaver);
% x_no(find(y_data_in(1,1:length(x_data_in))>0)) = 1;
% x_no(find(y_data_in(1,1:length(x_data_in))<=0)) = 0;
% [sum(abs(x_data_in-x_no)),sum(abs( x_data_in- x_h))]
% end