function data_depuncturing = depuncturing(x_in, K)
data_depuncturing = zeros(3,K+3);
for i = 1:1:K
    data_depuncturing(1,i) = x_in(2*i-1);
end
for i = 1:2:K-1
    data_depuncturing(2,i) = x_in(2*i);
    data_depuncturing(3,i+1) = x_in(2*i+2);
end
data_depuncturing(1,K+1) = x_in(2*K+1);
data_depuncturing(2,K+1) = x_in(2*K+2);
data_depuncturing(1,K+2) = x_in(2*K+3);
data_depuncturing(2,K+2) = x_in(2*K+4);
data_depuncturing(1,K+3) = x_in(2*K+5);
data_depuncturing(2,K+3) = x_in(2*K+6);
data_depuncturing(3,K+1) = x_in(2*K+8);
data_depuncturing(3,K+2) = x_in(2*K+10);
data_depuncturing(3,K+3) = x_in(2*K+12);
end