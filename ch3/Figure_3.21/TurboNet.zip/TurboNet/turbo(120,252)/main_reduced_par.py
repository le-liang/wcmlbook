# coding: UTF-8

# 只保留求外信息时的参数
import numpy as np
import tensorflow as tf
import pandas as pd
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'

K = 96
Batch_size = 500
BS_Test = 20000
Num_epochs = 10
SNR = 2
print('K: %d, SNR: %g' % (K, SNR))
# Num_testing = 1e4
filename_X_test = '3X_test_' + str('{:g}'.format(SNR)) + 'dB(2000000).csv'
filename_Y_test = '3Y_test_' + str('{:g}'.format(SNR)) + 'dB(2000000).csv'
filename_ber_neural = '3ber_' + str('{:g}'.format(SNR)) + 'dB_TurboNet+.csv'
filename_ber_plain = '3ber_' + str('{:g}'.format(SNR)) + 'dB_max-log-MAP2.csv'

# Num_testing = 1e4
filename_X_train = '6X_train_-1dB(60000).csv'
filename_Y_train = '6Y_train_-1dB(60000).csv'
filename_LLR_train = '6LLR_train_-1dB(60000).csv'
# filename_ber_neural = '3ber_' + str('{:g}'.format(SNR)) + 'dB_TurboNet+.csv'
X_train_data = np.loadtxt(filename_X_train, delimiter=',')
# Y_train_data = np.loadtxt('6Y_train_0dB(puncturing).csv', delimiter=',')
LLR_train_data = np.loadtxt(filename_LLR_train, delimiter=',')
X_test_data = np.loadtxt(filename_X_test, delimiter=',')
Y_test_data = np.loadtxt(filename_Y_test, delimiter=',')

Num_training = X_train_data.shape[0]
Num_testing = X_test_data.shape[0]

X_train_data_s_part1 = X_train_data[:, 0:3*K:3]
X_train_data_p1_part1 = X_train_data[:, 1:3*K:3]
X_train_data_p2_part1 = X_train_data[:, 2:3*K:3]
X_train_data_s_part2 = X_train_data[:, 3*K:3*K+6:2]
X_train_data_p1_part2 = X_train_data[:, 3*K+1:3*K+6:2]
X_train_data_s_part3 = X_train_data[:, 3*K+6:3*K+12:2]
X_train_data_p2_part2 = X_train_data[:, 3*K+7:3*K+12:2]

X_test_data_s_part1 = X_test_data[:, 0:3*K:3]
X_test_data_p1_part1 = X_test_data[:, 1:3*K:3]
X_test_data_p2_part1 = X_test_data[:, 2:3*K:3]
X_test_data_s_part2 = X_test_data[:, 3*K:3*K+6:2]
X_test_data_p1_part2 = X_test_data[:, 3*K+1:3*K+6:2]
X_test_data_s_part3 = X_test_data[:, 3*K+6:3*K+12:2]
X_test_data_p2_part2 = X_test_data[:, 3*K+7:3*K+12:2]

llr_e_train_init = np.zeros([Num_training, K+3])
llr_e_test_init = np.zeros([Num_testing, K+3])
X_train_data_new = np.hstack((X_train_data_s_part1,
                              X_train_data_s_part2,
                              X_train_data_s_part3,
                              X_train_data_p1_part1,
                              X_train_data_p1_part2,
                              X_train_data_p2_part1,
                              X_train_data_p2_part2,
                              llr_e_train_init))

X_test_data_new = np.hstack((X_test_data_s_part1,
                             X_test_data_s_part2,
                             X_test_data_s_part3,
                             X_test_data_p1_part1,
                             X_test_data_p1_part2,
                             X_test_data_p2_part1,
                             X_test_data_p2_part2,
                             llr_e_test_init))

x_in = tf.placeholder(tf.float64, [None, 3*K+12+K+3])
y_out = tf.placeholder(tf.float64, [None, K])
llr_out = tf.placeholder(tf.float64, [None, K])
# x_test = tf.placeholder(tf.float64, [None, (K+3)*3])
# y_test = tf.placeholder(tf.float64, [None, K+3])
num_data_float = tf.placeholder(tf.float64)
num_data = tf.to_int32(num_data_float)
alpha0 = tf.placeholder(tf.float64, [None, 8])
betan = tf.placeholder(tf.float64, [None, 8])


alpha0_value_train_init = np.zeros([Batch_size, 8])
alpha0_value_train_init[:, 1:8:1] = -128
betan_value_train_init = np.zeros([Batch_size, 8])
betan_value_train_init[:, 1:8:1] = -128

alpha0_value_test_init = np.zeros([Num_testing, 8])
alpha0_value_test_init[:, 1:8:1] = -128
betan_value_test_init = np.zeros([Num_testing, 8])
betan_value_test_init[:, 1:8:1] = -128


def interleave(data):
    f1 = 11
    f2 = 24
    k = 96
    # size = np.array(data.shape, dtype=int)[0]
    size = num_data
    dic = dict.fromkeys(range(k), 0)
    for i in range(k):
        dic[i] = tf.slice(data, [0, (f1*i+f2*i*i) % k], [size, 1])
    output = tf.concat([dic[i] for i in range(k)], axis=1)
    return output


def de_interleave(data):
    f1 = 11
    f2 = 24
    k = 96
    # size = np.array(data.shape, dtype=int)[0]
    size = num_data
    dic = dict.fromkeys(range(k), 0)
    for i in range(k):
        dic[(f1*i+f2*i*i) % k] = tf.slice(data, [0, i], [size, 1])
    output = tf.concat([dic[i] for i in range(k)], axis=1)
    return output


def get_batch(data, label, batch_size, num_epoch):
    input_queue = tf.train.slice_input_producer([data, label], num_epochs=num_epoch, shuffle=False, capacity=32)
    x_batch, y_batch = tf.train.batch(input_queue, batch_size=batch_size, num_threads=1, capacity=32,
                                      allow_smaller_final_batch=False)
    return x_batch, y_batch


def w_01_alpha_update0(size, i):
    d0 = np.array([[1, 0, 0, 0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 1, 0, 0, 0],
                   [0, 0, 0, 0, 0, 1, 0, 0],
                   [0, 1, 0, 0, 0, 0, 0, 0],
                   [0, 0, 1, 0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0, 0, 1, 0],
                   [0, 0, 0, 0, 0, 0, 0, 1],
                   [0, 0, 0, 1, 0, 0, 0, 0]])
    w_01_alp_0 = np.zeros([(8+(size+3)*8), 8])
    for j in range(8):
        for k in range(8):
            w_01_alp_0[j, k] = d0[j, k]
    index_vector = np.arange(8*(i+1), 8*(i+2), 1)
    for j in index_vector:
        for k in range(8):
            w_01_alp_0[j, k] = d0[j-8*(i+1), k]
    return w_01_alp_0


def w_01_alpha_update1(size, i):
    d1 = np.array([[0, 0, 0, 0, 1, 0, 0, 0],
                   [1, 0, 0, 0, 0, 0, 0, 0],
                   [0, 1, 0, 0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0, 1, 0, 0],
                   [0, 0, 0, 0, 0, 0, 1, 0],
                   [0, 0, 1, 0, 0, 0, 0, 0],
                   [0, 0, 0, 1, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0, 0, 0, 1]])
    w_01_alp_1 = np.zeros([(8+(size+3)*8), 8])
    for j in range(8):
        for k in range(8):
            w_01_alp_1[j, k] = d1[j, k]
    index_vector = np.arange(8*(i+1), 8*(i+2), 1)
    for j in index_vector:
        for k in range(8):
            w_01_alp_1[j, k] = d1[j-8*(i+1), k]
    return w_01_alp_1


def w_01_beta_update0(size, i):
    d0_beta = np.array([[1, 0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 1, 0, 0, 0, 0],
                        [0, 0, 0, 0, 1, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0, 1],
                        [0, 1, 0, 0, 0, 0, 0, 0],
                        [0, 0, 1, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, 1, 0]])
    d0_gamma = np.array([[1, 0, 0, 0, 0, 0, 0, 0],
                        [0, 1, 0, 0, 0, 0, 0, 0],
                        [0, 0, 1, 0, 0, 0, 0, 0],
                        [0, 0, 0, 1, 0, 0, 0, 0],
                        [0, 0, 0, 0, 1, 0, 0, 0],
                        [0, 0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, 1, 0],
                        [0, 0, 0, 0, 0, 0, 0, 1]])
    w_01_beta_0 = np.zeros([(8+(size+3)*8), 8])
    for j in range(8):
        for k in range(8):
            w_01_beta_0[j, k] = d0_beta[j, k]
    index_vector = np.arange(((8+(size+3)*8)-8*(i+1)), ((8+(size+3)*8)-8*i), 1)
    for j in index_vector:
        for k in range(8):
            w_01_beta_0[j, k] = d0_gamma[j-((8+(size+3)*8)-8*(i+1)), k]
    return w_01_beta_0


def w_01_beta_update1(size, i):
    d1_beta = np.array([[0, 1, 0, 0, 0, 0, 0, 0],
                        [0, 0, 1, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, 1, 0],
                        [1, 0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 1, 0, 0, 0, 0],
                        [0, 0, 0, 0, 1, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0, 1]])
    d1_gamma = np.array([[1, 0, 0, 0, 0, 0, 0, 0],
                        [0, 1, 0, 0, 0, 0, 0, 0],
                        [0, 0, 1, 0, 0, 0, 0, 0],
                        [0, 0, 0, 1, 0, 0, 0, 0],
                        [0, 0, 0, 0, 1, 0, 0, 0],
                        [0, 0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, 1, 0],
                        [0, 0, 0, 0, 0, 0, 0, 1]])
    w_01_beta_1 = np.zeros([(8+(size+3)*8), 8])
    for j in range(8):
        for k in range(8):
            w_01_beta_1[j, k] = d1_beta[j, k]
    index_vector = np.arange(((8+(size+3)*8)-8*(i+1)), ((8+(size+3)*8)-8*i), 1)
    for j in index_vector:
        for k in range(8):
            w_01_beta_1[j, k] = d1_gamma[j-((8+(size+3)*8)-8*(i+1)), k]
    return w_01_beta_1


def w_01_llr0_part1(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i), j] = 1
    return w_llr0


def w_01_llr0_part2(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+1, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 4), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 1), j] = 1
    return w_llr0


def w_01_llr0_part3(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+2, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 5), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 2), j] = 1
    return w_llr0


def w_01_llr0_part4(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+3, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 1), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 3), j] = 1
    return w_llr0


def w_01_llr0_part5(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+4, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 2), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 4), j] = 1
    return w_llr0


def w_01_llr0_part6(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+5, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 6), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 5), j] = 1
    return w_llr0


def w_01_llr0_part7(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+6, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 7), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 6), j] = 1
    return w_llr0


def w_01_llr0_part8(size):
    w_llr0 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr0[8*i+7, j] = 1
        w_llr0[((size + 4) * 8 + 8 * i + 8 + 3), j] = 1
        w_llr0[((size + 4) * 8 * 2 + 8 * i + 7), j] = 1
    return w_llr0


def w_01_llr1_part1(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 4), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i), j] = 1
    return w_llr1


def w_01_llr1_part2(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+1, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 0), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 1), j] = 1
    return w_llr1


def w_01_llr1_part3(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+2, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 1), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 2), j] = 1
    return w_llr1


def w_01_llr1_part4(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+3, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 5), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 3), j] = 1
    return w_llr1


def w_01_llr1_part5(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+4, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 6), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 4), j] = 1
    return w_llr1


def w_01_llr1_part6(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+5, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 2), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 5), j] = 1
    return w_llr1


def w_01_llr1_part7(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+6, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 3), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 6), j] = 1
    return w_llr1


def w_01_llr1_part8(size):
    w_llr1 = np.zeros([((size+4)*8*2+(size+3)*8), (size+3)])
    for i in range((size+3)):
        j = i
        w_llr1[8*i+7, j] = 1
        w_llr1[((size + 4) * 8 + 8 * i + 8 + 7), j] = 1
        w_llr1[((size + 4) * 8 * 2 + 8 * i + 7), j] = 1
    return w_llr1


def w_llr_e_out_value(size):
    w_llr_e_out = np.zeros([(3*(size+3)), (size+3)])
    for i in range((size+3)):
        w_llr_e_out[i, i] = 1
        w_llr_e_out[(size+3+i), i] = 1
        w_llr_e_out[2*(size+3)+i, i] = 1
    return w_llr_e_out


def w_01_llr_e_out_shape(size):
    w_01_llr_e_out = np.zeros([(3 * (size + 3)), (size + 3)])
    for i in range((size + 3)):
        w_01_llr_e_out[i, i] = 1
        w_01_llr_e_out[(size + 3 + i), i] = -1
        w_01_llr_e_out[2 * (size + 3) + i, i] = -1
    return w_01_llr_e_out


def get_max1(data1, data2):
    data1 = tf.expand_dims(data1, 0)
    data2 = tf.expand_dims(data2, 0)
    data = tf.concat([data1, data2], 0)
    data_max = tf.reduce_max(data, reduction_indices=[0])
    return data_max


def get_max2(data1, data2, data3, data4, data5, data6, data7, data8):
    data1 = tf.expand_dims(data1, 0)
    data2 = tf.expand_dims(data2, 0)
    data3 = tf.expand_dims(data3, 0)
    data4 = tf.expand_dims(data4, 0)
    data5 = tf.expand_dims(data5, 0)
    data6 = tf.expand_dims(data6, 0)
    data7 = tf.expand_dims(data7, 0)
    data8 = tf.expand_dims(data8, 0)
    data = tf.concat([data1, data2, data3, data4, data5, data6, data7, data8], 0)
    data_max = tf.reduce_max(data, reduction_indices=[0])
    return data_max


def get_vars_name(name):
    return [var for var in tf.global_variables() if name in var.name]


def sub_decode(x, example_number):
    k_length = 96
    # w1_init = [1/2 for i in range((k_length+3)*3)]
    # w1 = tf.Variable(w1_init, dtype=tf.float64)
    # gamma1_init = [0 for i in range((k_length+3)*12)]
    # gamma1 = tf.Variable(gamma1_init, trainable=False, dtype=tf.float64)
    # lc = tf.Variable(0.02, tf.float64)
    # lc = 1
    c = 0.0
    b_llr_init = 0.0
    # calculate gamma1
    init_a1 = np.array([[1, 1, 1],
                        [1, 1, 1],
                        [1, 0, 1],
                        [1, 0, 1],
                        [1, 0, 1],
                        [1, 0, 1],
                        [1, 1, 1],
                        [1, 1, 1]]).T
    b1 = np.ones([3, 8])
    w1_init = np.zeros([(k_length+3)*3, (k_length+3)*8])  # 用于构造01矩阵
    w1_value_init = np.zeros([(k_length+3)*3, (k_length+3)*8])  # 用于对权重初始化
    # for i in range((k_length+3)):
    #     j = 8*i
    #     for m in range(3):
    #         for n in range(8):
    #             w1_value_init[3 * i + m, j + n] = a1[m, n]
    #             w1_init[3*i+m, j+n] = b1[m, n]
    for i in range((k_length+3)):
        for j in range(8):
            w1_value_init[i, (8*i+j)] = b1[0, j]
            w1_value_init[(k_length+3+i), (8*i+j)] = b1[1, j]
            w1_value_init[(2*(k_length+3)+i), (8*i+j)] = b1[2, j]
            w1_init[i, (8 * i + j)] = 0.5 * init_a1[0, j]
            w1_init[(k_length + 3 + i), (8 * i + j)] = 0.5 * init_a1[1, j]
            w1_init[(2 * (k_length + 3) + i), (8 * i + j)] = 0.5 * init_a1[2, j]
    w1_01 = tf.constant(w1_init, dtype=tf.float64)
    w1_gamma = tf.Variable(w1_value_init, dtype=tf.float64, name='gamma1_w')
    w1_gamma = w1_01 * w1_gamma
    b1_value_init = [c for i in range((k_length+3)*8)]
    b1_gamma = tf.Variable(b1_value_init, dtype=tf.float64, name='gamma1_b')
    gamma1 = tf.matmul(x, w1_01)
# calculate gamma0
    a0 = np.array([[0, 0, 0],
                   [0, 0, 0],
                   [0, 1, 0],
                   [0, 1, 0],
                   [0, 1, 0],
                   [0, 1, 0],
                   [0, 0, 0],
                   [0, 0, 0]]).T
    b0 = np.ones([3, 8])
    w0_init = np.zeros([(k_length+3)*3, (k_length+3)*8])
    w0_value_init = np.zeros([(k_length+3)*3, (k_length+3)*8])
    # for i in range((k_length+3)):
    #     j = 8*i
    #     for m in range(3):
    #         for n in range(8):
    #             w0_value_init[3 * i + m, j + n] = a0[m, n]
    #             w0_init[3*i+m, j+n] = b0[m, n]
    for i in range((k_length+3)):
        for j in range(8):
            w0_value_init[i, (8*i+j)] = b0[0, j]
            w0_value_init[(k_length+3+i), (8*i+j)] = b0[1, j]
            w0_value_init[(2*(k_length+3)+i), (8*i+j)] = b0[2, j]
            w0_init[i, (8 * i + j)] = 0.5 * a0[0, j]
            w0_init[(k_length + 3 + i), (8 * i + j)] = 0.5 * a0[1, j]
            w0_init[(2 * (k_length + 3) + i), (8 * i + j)] = 0.5 * a0[2, j]
    w0_01 = tf.constant(w0_init, dtype=tf.float64)
    w0_gamma = tf.Variable(w0_value_init, dtype=tf.float64, name='gamma0_w')
    w0_gamma = w0_01 * w0_gamma
    b0_value_init = [c for i in range((k_length+3)*8)]
    b0_gamma = tf.Variable(b0_value_init, dtype=tf.float64, name='gamma0_b')
    gamma0 = tf.matmul(x, w0_01)

    # calculate alpha beta
    # alpha0_value_init = tf.zeros([example_number, 8])
    # alpha0_value_init[:, 1:8:1] = -10e10
    # alpha0 = tf.constant(alpha0_value_init, dtype=tf.float64)
    # alpha0 = tf.zeros([example_number, 8], dtype=tf.float64)
    # alpha0[:, 1:8:1] = -10e10

    # alpha0 = tf.constant(alpha0_value_init, dtype=tf.float64)
    alpha_temp = alpha0
    alpha = alpha0
    # betan_value_init = np.zeros([example_number, 8])
    # betan_value_init[:, 1:8:1] = -10e10
    # betan = tf.constant(betan_value_init, dtype=tf.float64)
    # betan = tf.zeros([example_number, 8], dtype=tf.float64)
    # betan[:, 1:8:1] = -10e10
    # betan = tf.constant(betan_value_init, dtype=tf.float64)
    beta_temp = betan
    beta = betan
    temp1 = betan
    temp2 = betan
    for i in range(k_length+3):
        alp_gam0 = tf.concat([alpha_temp, gamma0], axis=1)
        w_01_alpha0 = tf.constant(w_01_alpha_update0(k_length, i), dtype=tf.float64)
        alpha_temp_part1 = tf.matmul(alp_gam0, w_01_alpha0)
        alp_gam1 = tf.concat([alpha_temp, gamma1], axis=1)
        w_01_alpha1 = tf.constant(w_01_alpha_update1(k_length, i), dtype=tf.float64)
        alpha_temp_part2 = tf.matmul(alp_gam1, w_01_alpha1)
        alpha_temp = get_max1(alpha_temp_part1, alpha_temp_part2)
        alpha = tf.concat([alpha, alpha_temp], axis=1)

        be_gam0 = tf.concat([beta_temp, gamma0], axis=1)
        w_01_beta0 = tf.constant(w_01_beta_update0(k_length, i), dtype=tf.float64)
        beta_temp_part1 = tf.matmul(be_gam0, w_01_beta0)
        temp1 = tf.concat([beta_temp_part1, temp1], axis=1)
        be_gam1 = tf.concat([beta_temp, gamma1], axis=1)
        w_01_beta1 = tf.constant(w_01_beta_update1(k_length, i), dtype=tf.float64)
        beta_temp_part2 = tf.matmul(be_gam1, w_01_beta1)
        temp2 = tf.concat([beta_temp_part2, temp2], axis=1)
        beta_temp = get_max1(beta_temp_part1, beta_temp_part2)
        beta = tf.concat([beta_temp, beta], axis=1)

    alp_be_gam0 = tf.concat([alpha, beta, gamma0], axis=1)
    alp_be_gam1 = tf.concat([alpha, beta, gamma1], axis=1)
    b_llr_value_init = [b_llr_init for i in range(k_length + 3)]
    w0_llr_part1_init = np.ones([((k_length+4)*8*2+(k_length+3)*8), (k_length+3)])
    w0_llr_part1_shape = tf.constant(w_01_llr0_part1(k_length), dtype=tf.float64)
    w0_llr_part1 = w0_llr_part1_shape * tf.Variable(w0_llr_part1_init, dtype=tf.float64, name='posterior_llr_0_part1_w')
    b0_llr_part1 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part1_b')
    llr0_part1 = tf.matmul(alp_be_gam0, w0_llr_part1_shape)
    w0_llr_part2_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part2_shape = tf.constant(w_01_llr0_part2(k_length), dtype=tf.float64)
    w0_llr_part2 = w0_llr_part2_shape * tf.Variable(w0_llr_part2_init, dtype=tf.float64, name='posterior_llr_0_part2_w')
    b0_llr_part2 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part2_b')
    llr0_part2 = tf.matmul(alp_be_gam0, w0_llr_part2_shape)
    w0_llr_part3_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part3_shape = tf.constant(w_01_llr0_part3(k_length), dtype=tf.float64)
    w0_llr_part3 = w0_llr_part3_shape * tf.Variable(w0_llr_part3_init, dtype=tf.float64, name='posterior_llr_0_part3_w')
    b0_llr_part3 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part3_b')
    llr0_part3 = tf.matmul(alp_be_gam0, w0_llr_part3_shape)
    w0_llr_part4_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part4_shape = tf.constant(w_01_llr0_part4(k_length), dtype=tf.float64)
    w0_llr_part4 = w0_llr_part4_shape * tf.Variable(w0_llr_part4_init, dtype=tf.float64, name='posterior_llr_0_part4_w')
    b0_llr_part4 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part4_b')
    llr0_part4 = tf.matmul(alp_be_gam0, w0_llr_part4_shape)
    w0_llr_part5_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part5_shape = tf.constant(w_01_llr0_part5(k_length), dtype=tf.float64)
    w0_llr_part5 = w0_llr_part5_shape * tf.Variable(w0_llr_part5_init, dtype=tf.float64, name='posterior_llr_0_part5_w')
    b0_llr_part5 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part5_b')
    llr0_part5 = tf.matmul(alp_be_gam0, w0_llr_part5_shape)
    w0_llr_part6_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part6_shape = tf.constant(w_01_llr0_part6(k_length), dtype=tf.float64)
    w0_llr_part6 = w0_llr_part6_shape * tf.Variable(w0_llr_part6_init, dtype=tf.float64, name='posterior_llr_0_part6_w')
    b0_llr_part6 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part6_b')
    llr0_part6 = tf.matmul(alp_be_gam0, w0_llr_part6_shape)
    w0_llr_part7_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part7_shape = tf.constant(w_01_llr0_part7(k_length), dtype=tf.float64)
    w0_llr_part7 = w0_llr_part7_shape * tf.Variable(w0_llr_part7_init, dtype=tf.float64, name='posterior_llr_0_part7_w')
    b0_llr_part7 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part7_b')
    llr0_part7 = tf.matmul(alp_be_gam0, w0_llr_part7_shape)
    w0_llr_part8_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w0_llr_part8_shape = tf.constant(w_01_llr0_part8(k_length), dtype=tf.float64)
    w0_llr_part8 = w0_llr_part8_shape * tf.Variable(w0_llr_part8_init, dtype=tf.float64, name='posterior_llr_0_part8_w')
    b0_llr_part8 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_0_part8_b')
    llr0_part8 = tf.matmul(alp_be_gam0, w0_llr_part8_shape)
    llr_0 = get_max2(llr0_part1, llr0_part2, llr0_part3, llr0_part4, llr0_part5, llr0_part6, llr0_part7, llr0_part8)

    w1_llr_part1_init = np.ones([((k_length + 4) * 8 * 2 + (k_length+3) * 8), (k_length + 3)])
    w1_llr_part1_shape = tf.constant(w_01_llr1_part1(k_length), dtype=tf.float64)
    w1_llr_part1 = w1_llr_part1_shape * tf.Variable(w1_llr_part1_init, dtype=tf.float64, name='posterior_llr_1_part1_w')
    b1_llr_part1 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part1_b')
    llr1_part1 = tf.matmul(alp_be_gam1, w1_llr_part1_shape)
    w1_llr_part2_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part2_shape = tf.constant(w_01_llr1_part2(k_length), dtype=tf.float64)
    w1_llr_part2 = w1_llr_part2_shape * tf.Variable(w1_llr_part2_init, dtype=tf.float64, name='posterior_llr_1_part2_w')
    b1_llr_part2 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part2_b')
    llr1_part2 = tf.matmul(alp_be_gam1, w1_llr_part2_shape)
    w1_llr_part3_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part3_shape = tf.constant(w_01_llr1_part3(k_length), dtype=tf.float64)
    w1_llr_part3 = w1_llr_part3_shape * tf.Variable(w1_llr_part3_init, dtype=tf.float64, name='posterior_llr_1_part3_w')
    b1_llr_part3 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part3_b')
    llr1_part3 = tf.matmul(alp_be_gam1, w1_llr_part3_shape)
    w1_llr_part4_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part4_shape = tf.constant(w_01_llr1_part4(k_length), dtype=tf.float64)
    w1_llr_part4 = w1_llr_part4_shape * tf.Variable(w1_llr_part4_init, dtype=tf.float64, name='posterior_llr_1_part4_w')
    b1_llr_part4 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part4_b')
    llr1_part4 = tf.matmul(alp_be_gam1, w1_llr_part4_shape)
    w1_llr_part5_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part5_shape = tf.constant(w_01_llr1_part5(k_length), dtype=tf.float64)
    w1_llr_part5 = w1_llr_part5_shape * tf.Variable(w1_llr_part5_init, dtype=tf.float64, name='posterior_llr_1_part5_w')
    b1_llr_part5 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part5_b')
    llr1_part5 = tf.matmul(alp_be_gam1, w1_llr_part5_shape)
    w1_llr_part6_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part6_shape = tf.constant(w_01_llr1_part6(k_length), dtype=tf.float64)
    w1_llr_part6 = w1_llr_part6_shape * tf.Variable(w1_llr_part6_init, dtype=tf.float64, name='posterior_llr_1_part6_w')
    b1_llr_part6 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part6_b')
    llr1_part6 = tf.matmul(alp_be_gam1, w1_llr_part6_shape)
    w1_llr_part7_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part7_shape = tf.constant(w_01_llr1_part7(k_length), dtype=tf.float64)
    w1_llr_part7 = w1_llr_part7_shape * tf.Variable(w1_llr_part7_init, dtype=tf.float64, name='posterior_llr_1_part7_w')
    b1_llr_part7 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part7_b')
    llr1_part7 = tf.matmul(alp_be_gam1, w1_llr_part7_shape)
    w1_llr_part8_init = np.ones([((k_length + 4) * 8 * 2 + (k_length + 3) * 8), (k_length + 3)])
    w1_llr_part8_shape = tf.constant(w_01_llr1_part8(k_length), dtype=tf.float64)
    w1_llr_part8 = w1_llr_part8_shape * tf.Variable(w1_llr_part8_init, dtype=tf.float64, name='posterior_llr_1_part8_w')
    b1_llr_part8 = tf.Variable(b_llr_value_init, dtype=tf.float64, name='posterior_llr_1_part8_b')
    llr1_part8 = tf.matmul(alp_be_gam1, w1_llr_part8_shape)
    llr_1 = get_max2(llr1_part1, llr1_part2, llr1_part3, llr1_part4, llr1_part5, llr1_part6, llr1_part7, llr1_part8)

    llr = llr_1 - llr_0
    y_s = tf.slice(x, [0, 0], [example_number, (k_length+3)])
    llr_e_in = tf.slice(x, [0, 2*(k_length+3)], [example_number, (k_length+3)])
    llr_ys_llrein = tf.concat([llr, y_s, llr_e_in], axis=1)

    w_01_llr_e_output = tf.constant(w_01_llr_e_out_shape(k_length), dtype=tf.float64)
    w_llr_e_out_init = w_llr_e_out_value(k_length)
    w_llr_e_out = tf.Variable(w_llr_e_out_init, dtype=tf.float64, name='extrinsic_llr_w')
    w_llr_e_output = w_01_llr_e_output * w_llr_e_out
    b_llr_e_output_value_init = 0.0
    b_llr_e_output_init = [b_llr_e_output_value_init for i in range(k_length+3)]
    b_llr_e_output = tf.Variable(b_llr_e_output_init, dtype=tf.float64, name='extrinsic_llr_b')
    llr_e_output = tf.matmul(llr_ys_llrein, w_llr_e_output) + b_llr_e_output
    para_list = []
    para_list += [w_llr_e_output, b_llr_e_output]
    return llr_e_output, llr, para_list


with tf.variable_scope('iteration_1'):
    with tf.variable_scope('subnet_1'):
        input1_part1 = tf.slice(x_in, [0, 0], [num_data, K + 3])
        input1_part2 = tf.slice(x_in, [0, K + 6], [num_data, K + 3])
        input1_part3 = tf.slice(x_in, [0, 3 * K + 12], [num_data, K + 3])
        input1 = tf.concat([input1_part1, input1_part2, input1_part3], axis=1)
        output1, llr1, a1 = sub_decode(input1, num_data)
        # 对s交织，和s2拼接在一起，与p2和output1的交织拼接成input2
    with tf.variable_scope('subnet_2'):
        s = tf.slice(x_in, [0, 0], [num_data, K])
        input2_part1_1 = interleave(s)
        input2_part1_2 = tf.slice(x_in, [0, K + 3], [num_data, 3])
        input2_part1 = tf.concat([input2_part1_1, input2_part1_2], axis=1)
        input2_part2 = tf.slice(x_in, [0, 2 * K + 9], [num_data, K + 3])
        input2_part3_1 = interleave(tf.slice(output1, [0, 0], [num_data, K]))
        input2_part3_2 = tf.zeros([num_data, 3], dtype=tf.float64)
        input2_part3 = tf.concat([input2_part3_1, input2_part3_2], axis=1)
        input2 = tf.concat([input2_part1, input2_part2, input2_part3], axis=1)
        output2, llr2, a2 = sub_decode(input2, num_data)

with tf.variable_scope('iteration_2'):
    with tf.variable_scope('subnet_1'):
        input3_part3_1 = de_interleave(tf.slice(output2, [0, 0], [num_data, K]))
        # input3_part3_2 = tf.slice(output1, [0, K], [num_data, 3])
        input3_part3_2 = tf.zeros([num_data, 3], dtype=tf.float64)
        input3_part3 = tf.concat([input3_part3_1, input3_part3_2], axis=1)
        input3 = tf.concat([input1_part1, input1_part2, input3_part3], axis=1)
        output3, llr3, a3 = sub_decode(input3, num_data)
    with tf.variable_scope('subnet_2'):
        input4_part3_1 = interleave(tf.slice(output3, [0, 0], [num_data, K]))
        # input4_part3_2 = tf.slice(output2, [0, K], [num_data, 3])
        input4_part3_2 = tf.zeros([num_data, 3], dtype=tf.float64)
        input4_part3 = tf.concat([input4_part3_1, input4_part3_2], axis=1)
        input4 = tf.concat([input2_part1, input2_part2, input4_part3], axis=1)
        output4, llr4, a4 = sub_decode(input4, num_data)

with tf.variable_scope('iteration_3'):
    with tf.variable_scope('subnet_1'):
        input5_part3_1 = de_interleave(tf.slice(output4, [0, 0], [num_data, K]))
        # input5_part3_2 = tf.slice(output3, [0, K], [num_data, 3])
        input5_part3_2 = tf.zeros([num_data, 3], dtype=tf.float64)
        input5_part3 = tf.concat([input5_part3_1, input5_part3_2], axis=1)
        input5 = tf.concat([input1_part1, input1_part2, input5_part3], axis=1)
        output5, llr5, a5 = sub_decode(input5, num_data)
    with tf.variable_scope('subnet_2'):
        input6_part3_1 = interleave(tf.slice(output5, [0, 0], [num_data, K]))
        # input6_part3_2 = tf.slice(output4, [0, K], [num_data, 3])
        input6_part3_2 = tf.zeros([num_data, 3], dtype=tf.float64)
        input6_part3 = tf.concat([input6_part3_1, input6_part3_2], axis=1)
        input6 = tf.concat([input2_part1, input2_part2, input6_part3], axis=1)
        output6, llr6, a6 = sub_decode(input6, num_data)

# output_data_2 = tf.slice(llr2, [0, 0], [num_data, K])
# output_valid_2 = de_interleave(output_data_2)
# output_data_4 = tf.slice(llr4, [0, 0], [num_data, K])
# output_valid_4 = de_interleave(output_data_4)
output_data_6 = tf.slice(llr6, [0, 0], [num_data, K])
output_valid_6 = de_interleave(output_data_6)
# loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=output_valid, labels=y_out))

# out = tf.round(tf.sigmoid(output_valid))
out = tf.sigmoid(output_valid_6)
# loss = tf.reduce_mean(tf.reduce_sum(tf.square(out - y_out), reduction_indices=[1]))
loss = tf.reduce_mean(tf.square(output_valid_6 - y_out))

optimizer = tf.train.AdamOptimizer(learning_rate=8e-4).minimize(loss)  # 1e-4
err_rate = tf.reduce_sum(tf.abs(tf.round(out) - y_out))/(num_data_float * K)
x_batch_train, y_batch_train = get_batch(data=X_train_data_new, label=LLR_train_data,
                                         batch_size=Batch_size, num_epoch=Num_epochs)

# name_list_gamma1_w = get_vars_name('iteration_3/subnet_2/gamma1_w')
# name_list_gamma1_b = get_vars_name('iteration_3/subnet_2/gamma1_b')
# name_list_gamma0_w = get_vars_name('iteration_3/subnet_2/gamma0_w')
# name_list_gamma0_b = get_vars_name('iteration_3/subnet_2/gamma0_b')
name_list_extrinsic_w = get_vars_name('iteration_1/subnet_1/extrinsic_llr_w')
# name_list_extrinsic_b = get_vars_name('iteration_3/subnet_2/extrinsic_llr_b')
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
saver = tf.train.Saver()
with tf.Session(config=config) as sess:
    # 初始化参数
    sess.run(tf.global_variables_initializer())
    sess.run(tf.local_variables_initializer())

    # print(name_list_extrinsic_w)
    # 开启协调器
    coord = tf.train.Coordinator()
    # 使用start_queue_runners 启动队列填充
    threads = tf.train.start_queue_runners(sess, coord)
    epoch = 0
    ber_vector = [1.0 for i in range(int(Num_training * Num_epochs / Batch_size))]
    try:
        while not coord.should_stop():
            # 获取训练用的每一个batch中batch_size个样本和标签
            if epoch == 0:
                '''
                ber0 = err_rate.eval({x_in: X_test_data_new, y_out: Y_test_data, num_data_float: Num_testing,
                                      alpha0: alpha0_value_test_init, betan: betan_value_test_init})
                '''
                ber0_sum = 0
                for i in range(int(Num_testing / BS_Test)):
                    ber0_i = err_rate.eval({x_in: X_test_data_new[i * BS_Test:(i + 1) * BS_Test:1, :],
                                            y_out: Y_test_data[i * BS_Test:(i + 1) * BS_Test:1, :],
                                            num_data_float: BS_Test,
                                            alpha0: alpha0_value_test_init[i * BS_Test:(i + 1) * BS_Test:1, :],
                                            betan: betan_value_test_init[i * BS_Test:(i + 1) * BS_Test:1, :]})
                    ber0_sum = ber0_sum + ber0_i
                ber0 = ber0_sum / (Num_testing / BS_Test)
                print(ber0)
                ber0_list = [ber0]
                pd.DataFrame(data=ber0_list).to_csv(filename_ber_plain)
            feature_train, label_train = sess.run([x_batch_train, y_batch_train])
            sess.run(optimizer, feed_dict={x_in: feature_train, y_out: label_train, num_data_float: Batch_size,
                                           alpha0: alpha0_value_train_init, betan: betan_value_train_init})
            # train_ber = err_rate.eval({x_in: feature_train, y_out: label_train, num_data_float: Batch_size,
            #                            alpha0: alpha0_value_train_init, betan: betan_value_train_init})

            # ************************ Calculate Trian Loss **********************
            # train_loss = loss.eval({x_in: feature_train, y_out: label_train, num_data_float: Batch_size,
            #                         alpha0: alpha0_value_train_init, betan: betan_value_train_init})

            # para = sess.run(a6, feed_dict={x_in: feature_train, y_out: label_train, num_data_float: Batch_size,
            #                                alpha0: alpha0_value_train_init, betan: betan_value_train_init})

            # ************************ Calculate Test BER *************************
            '''
            ber_temp = err_rate.eval({x_in: X_test_data_new, y_out: Y_test_data, num_data_float: Num_testing,
                                      alpha0: alpha0_value_test_init, betan: betan_value_test_init})
            '''

            ber_temp_sum = 0
            for j in range(int(Num_testing / BS_Test)):
                ber_temp_j = err_rate.eval({x_in: X_test_data_new[j * BS_Test:(j + 1) * BS_Test:1, :],
                                            y_out: Y_test_data[j * BS_Test:(j + 1) * BS_Test:1, :],
                                            num_data_float: BS_Test,
                                            alpha0: alpha0_value_test_init[j * BS_Test:(j + 1) * BS_Test:1, :],
                                            betan: betan_value_test_init[j * BS_Test:(j + 1) * BS_Test:1, :]})
                ber_temp_sum = ber_temp_sum + ber_temp_j
            ber_temp = ber_temp_sum / (Num_testing / BS_Test)

            # print(name_list)
            # gamma1_w = sess.run(name_list_gamma1_w[0])
            # print(w)
            # gamma1_b = sess.run(name_list_gamma1_b[0])
            # gamma0_w = sess.run(name_list_gamma0_w[0])
            # gamma0_b = sess.run(name_list_gamma0_b[0])
            # extrinsic_w = sess.run(name_list_extrinsic_w[0])
            # extrinsic_b = sess.run(name_list_extrinsic_b[0])
            # print(b)
            # ********************** Save Parameters *********************
            # if epoch % 10 == 0:
            #     print(epoch)
            #     filename_parameters = 'TurboNet\\it1_sub1_extrinsic_w_' + str('{:g}'.format(epoch)) + '.csv'
            #     # np.savetxt('gamma1_w.csv', gamma1_w, delimiter=',')
            #     # np.savetxt('gamma1_b.csv', gamma1_b, delimiter=',')
            #     # np.savetxt('gamma0_w.csv', gamma0_w, delimiter=',')
            #     # np.savetxt('gamma0_b.csv', gamma0_b, delimiter=',')
            #     np.savetxt(filename_parameters, extrinsic_w, delimiter=',')
            #     # np.savetxt('extrinsic_b.csv', extrinsic_b, delimiter=',')


            # print(para)
            # file = open('weights.txt', 'w')
            # for fp in para:
            #     file.write(str(fp))
            #     file.write('\n')
            # file.close()
            # np.savetxt('weights.csv', para[0], delimiter=',')

            # ****************** Save BER *******************
            # min_ber = min(ber_vector)
            ber_vector[epoch] = ber_temp

            # print(ber_temp)
            pd.DataFrame(data=ber_vector).to_csv(filename_ber_neural)
            # a = sess.run(train_ber)

            # test_accuracy = accuracy.eval({x: test_x, y: test_y})
            # if epoch % 1 == 0:
            #     test_ber = err_rate.eval({x_in: X_test_data_new, y_out: Y_test_data, num_data_float: Num_testing,
            #                               alpha0: alpha0_value_test_init, betan: betan_value_test_init})
            #     test_loss = loss.eval({x_in: X_test_data_new, y_out: Y_test_data, num_data_float: Num_testing,
            #                            alpha0: alpha0_value_test_init, betan: betan_value_test_init})

            # *********************** Print Train Loss and Test BER ***********************
            # print("Num %d, Training loss %g, Testing ber %g" % (epoch, train_loss, ber_temp))
            print("Num %d, Testing ber %g" % (epoch, ber_temp))

            #     print("Num %d, Testing loss %g, Testing ber %g" % (epoch, test_loss, test_ber))
            #     print("******************************************")
            # np.savetxt('da.csv', out.eval({x_train: feature_train, y_train: label_train, num_data: 32,
            #            alpha0: alpha0_value_train_init, betan: betan_value_train_init}), delimiter=',')
            # np.savetxt('ber3dB.csv', test_ber, delimiter=',')
            # if epoch % 10 == 0:
            #     print("Epoch %d, Testing loss %g, Testing ber %g" % (epoch, test_loss, test_ber))
            # print(sess.run(w))
            # print("Epoch %d, Training accuracy %g" % (epoch, train_accuracy))

            # ********************* Save Model ***********************
            # if ber_temp < min_ber:
            #     # print('w')
            #     saver.save(sess, 'Model_min/TurboNet+')
            # if epoch >= int(700) - 5:
            #     saver.save(sess, 'Model/TurboNet+', global_step=epoch)

            # print("Epoch %d, Training accuracy %g, Testing accuracy %g" % (epoch, train_accuracy, test_accuracy))
            epoch = epoch + 1
    except tf.errors.OutOfRangeError:  # num_epochs 次数用完会抛出此异常

        print("---Train end---")
    finally:
        # 协调器coord发出所有线程终止信号
        coord.request_stop()
        print('---Programme end---')
    coord.join(threads)  # 把开启的线程加入主线程，等待threads结束
