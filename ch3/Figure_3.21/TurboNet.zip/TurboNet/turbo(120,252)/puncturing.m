function data_puncturing = puncturing(x_in, K)
data_puncturing = zeros(1,2*K+12);% code rate = 1/2; matrix = [1 1;1 0;0 1;]
for i = 1:1:K
    data_puncturing(2*i-1) = x_in(1,i);
end
for i = 1:2:K-1
    data_puncturing(2*i) = x_in(2,i);
    data_puncturing(2*i+2) = x_in(3,i+1);
end
data_puncturing(2*K+1) = x_in(1,K+1);
data_puncturing(2*K+2) = x_in(2,K+1);
data_puncturing(2*K+3) = x_in(1,K+2);
data_puncturing(2*K+4) = x_in(2,K+2);
data_puncturing(2*K+5) = x_in(1,K+3);
data_puncturing(2*K+6) = x_in(2,K+3);
data_puncturing(2*K+8) = x_in(3,K+1);
data_puncturing(2*K+10) = x_in(3,K+2);
data_puncturing(2*K+12) = x_in(3,K+3);
end