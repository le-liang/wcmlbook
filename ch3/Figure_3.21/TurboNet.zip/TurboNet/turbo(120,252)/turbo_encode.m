function output = turbo_encode(input,length,input_interleaver)
output = zeros(3,length+3);
reg1_1 = 0;
reg1_2 = 0;
reg1_3 = 0;
reg2_1 = 0;
reg2_2 = 0;
reg2_3 = 0;
for i=0:(length-1)
    bit = input(i+1);
    %X[k}
    output(1,i+1)=input(i+1);
    %Z[k}
    in= mod(bit+reg1_3+reg1_2,2);
    out=mod(reg1_3+reg1_1+in,2);
    reg1_3 = reg1_2;
	reg1_2 = reg1_1;
	reg1_1 = in;
    output(2,i+1) = out;
    %Z'[k]
    bit = input(input_interleaver(i+1)+1);
    in=mod(bit+reg2_3+reg2_2,2);
    out=mod(reg2_3+reg2_1+in,2);
    reg2_3 = reg2_2;
	reg2_2 = reg2_1;
	reg2_1 = in;
	output(3,i+1) = out;
end
%Tailing coder 1
for j=0:2
    bit = xor(reg1_3,reg1_2);
    output(1,length+1+j) = bit;
    in = xor(bit,xor(reg1_3,reg1_2));
    out = xor(reg1_3,xor(reg1_1,in));
    reg1_3 = reg1_2;
	reg1_2 = reg1_1;
	reg1_1 = in;
    output(2,length+1+j) = out;
end
%Tailing coder 2
for j=0:2
    bit = xor(reg2_3,reg2_2);
    in = xor(bit,xor(reg2_3,reg2_2));
    out = xor(reg2_3,xor(reg2_1,in));
    reg2_3 = reg2_2;
	reg2_2 = reg2_1;
	reg2_1 = in;
    output(3,length+1+j) = out;
end
end