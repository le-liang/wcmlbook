clear;
x_data_in = csvread('output.csv');
input_interleaver = turbo_interleaver(length(x_data_in));
% x_data_out=turbo_encode(x_data_in,length(x_data_in),input_interleaver);
% bpskSym = x_data_out;
% bpskSym(find(bpskSym<1))=-1;
% % for SNR = -3:0.2:3;%10*log10(0.5); % SNR is in dB unit, for power ratio
% SNR = 2;
% sigma = sqrt(1/(10^(SNR/10)));% the sigma of the Guassian function sigma^2 = No/2
% y_data_in(1,:) = awgn(bpskSym(1,:),SNR);
% y_data_in(2,:) = awgn(bpskSym(2,:),SNR);
% y_data_in(3,:)= awgn(bpskSym(3,:),SNR);
y = csvread('input.csv');
y_reshape = reshape(y,3,44);
y_clear = y(:,121:1:132);
y_data_in = y_reshape(:,1:1:43);
y_data_in(1,41) = y_clear(1,1);
y_data_in(2,41) = y_clear(1,2);
y_data_in(1,42) = y_clear(1,3);
y_data_in(2,42) = y_clear(1,4);
y_data_in(1,43) = y_clear(1,5);
y_data_in(2,43) = y_clear(1,6);
y_data_in(3,41) = y_clear(1,8);
y_data_in(3,42) = y_clear(1,10);
y_data_in(3,43) = y_clear(1,12);
iterNum=6;
x_N=length(y_data_in(1,:));
app=zeros(1,x_N);
LLR=zeros(1,x_N-3);
x_h=zeros(1,x_N-3);
x_dp=zeros(1,x_N);
% x_h = turbo_decode(iterNum,y_data_in,input_interleaver);
% x_no(find(y_data_in(1,1:length(x_data_in))>0)) = 1;
% x_no(find(y_data_in(1,1:length(x_data_in))<=0)) = 0;
% [sum(abs(x_data_in-x_no)),sum(abs( x_data_in- x_h))]
% end
for k=1:1:x_N-3
        app(k) = ex_info(input_interleaver(k)+1);
        x_dp(k) = y_data_in(1,input_interleaver(k)+1);
end