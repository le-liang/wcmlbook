function [x_h, LLR] = turbo_decode_logmap(iterNum,y_data_in,interleaver)
x_N=length(y_data_in(1,:));
app=zeros(1,x_N);
LLR=zeros(1,x_N-3);
x_h=zeros(1,x_N-3);
x_dp=zeros(1,x_N);
for i=1:1:iterNum
    %calculat the likelihoods output from decoder 1
    [softout,extInfo] = LogMAP([y_data_in(1,:);y_data_in(2,:)],app);

    %//permute decoder#1 likelihoods to match decoder#2 order
    for k=1:1:x_N-3
        app(k) = extInfo(interleaver(k)+1);
        x_dp(k) = y_data_in(1,interleaver(k)+1);
    end
    %calculat the likelihoods output from decoder 2
    [softout,extInfo] = LogMAP([x_dp;y_data_in(3,:)],app);

    %//inverse permute decoder#2 likelihoods to match decoder#1 order
    for k=1:1:x_N-3
        app(interleaver(k)+1) = extInfo(k);
    end
end
for k=1:1:x_N-3
        LLR(interleaver(k)+1) = softout(k);
end
x_h(find(LLR>0))=1;
end

