% ���
function soft_bits = demodulate_soft(rx_freq_data_syms,modu_type, sigma)
% ���룺��1�����2��3380�и������������ͣ�QPSK��������Ϊ2��6760��ʵ����
if strcmp(modu_type,'BPSK')
    % hard decision
%     soft_bits = real(rx_freq_data_syms); %�˴���õ�Ϊ��������
    soft_bits = 2*sqrt(2)*(real(rx_freq_data_syms)+imag(rx_freq_data_syms));
%     for i=1:length(soft_bits)  %תΪӲ�������
%         if soft_bits(i)<0
%             soft_bits(i)=0;
%         else
%             soft_bits(i)=1;
%         end
%     end
    
elseif strcmp(modu_type,'QPSK')
   
    soft_bits = zeros(1,2*length(rx_freq_data_syms));
    
%     for i=1:length(rx_freq_data_syms)  %תΪӲ�������
%         if real(rx_freq_data_syms(i))>0    
%             bit0(i) = 1;
%         else
%             bit0(i) = 0;
%         end
%         if imag(rx_freq_data_syms(i))>0
%             bit1(i) = 1;
%         else
%             bit1(i) = 0;
%         end
%     end
% 
%     soft_bits(1:2:length(soft_bits)) = bit0;  %--zhy--����λ
%     soft_bits(2:2:length(soft_bits)) = bit1;  %--zhy--ż��λ
    bit0 = zeros(1,length(rx_freq_data_syms));
    bit1 = zeros(1,length(rx_freq_data_syms));
    for i=1:length(rx_freq_data_syms)  %תΪ��������
            bit0(i) = real(rx_freq_data_syms(i));
            bit1(i) = imag(rx_freq_data_syms(i));
    end
    soft_bits(1:2:length(soft_bits)) = 2*sqrt(2)*bit0;  %--zhy--����λ
    soft_bits(2:2:length(soft_bits)) = 2*sqrt(2)*bit1;  %--zhy--ż��λ
    
elseif strcmp(modu_type,'16QAM')	
    Kmod=1/sqrt(10);
    soft_bits = zeros(1,4*length(rx_freq_data_syms));  % Each symbol consists of 4 bits���������ϱ�Ϊԭ����4����

    % hard decision
%     for i=1:length(rx_freq_data_syms)  %I·תΪӲ�������
%         if real(rx_freq_data_syms(i))>0    
%             bit0(i) = 1;
%             if real(rx_freq_data_syms(i))> 2*Kmod
%                 bit1(i) = 0;
%             else
%                 bit1(i) = 1;
%             end
%         else
%             bit0(i) = 0;
%             if real(rx_freq_data_syms(i))< (-2)*Kmod
%                 bit1(i) = 0;
%             else
%                 bit1(i) = 1;
%             end
%         end
%     end
%         for i=1:length(rx_freq_data_syms)  %Q·תΪӲ�������
%         if imag(rx_freq_data_syms(i))>0    
%             bit2(i) = 1;
%             if imag(rx_freq_data_syms(i))> 2*Kmod
%                 bit3(i) = 0;
%             else
%                 bit3(i) = 1;
%             end
%         else
%             bit2(i) = 0;
%             if imag(rx_freq_data_syms(i))< (-2)*Kmod
%                 bit3(i) = 0;
%             else
%                 bit3(i) = 1;
%             end
%         end
%     end

% soft decision

    bit0 = zeros(1, length(rx_freq_data_syms));
    bit1 = zeros(1, length(rx_freq_data_syms));
    bit2 = zeros(1, length(rx_freq_data_syms));
    bit3 = zeros(1, length(rx_freq_data_syms));
    for i=1:length(rx_freq_data_syms)  %תΪ��������
            bit0(i) = min((real(rx_freq_data_syms(i))+Kmod)^2,(real(rx_freq_data_syms(i))+3*Kmod)^2)-min((real(rx_freq_data_syms(i))-Kmod)^2,(real(rx_freq_data_syms(i))-3*Kmod)^2);
            bit1(i) = min((real(rx_freq_data_syms(i))+3*Kmod)^2,(real(rx_freq_data_syms(i))-3*Kmod)^2)-min((real(rx_freq_data_syms(i))+Kmod)^2,(real(rx_freq_data_syms(i))-Kmod)^2);
            bit2(i) = min((imag(rx_freq_data_syms(i))+Kmod)^2,(imag(rx_freq_data_syms(i))+3*Kmod)^2)-min((imag(rx_freq_data_syms(i))-Kmod)^2,(imag(rx_freq_data_syms(i))-3*Kmod)^2);
            bit3(i) = min((imag(rx_freq_data_syms(i))+3*Kmod)^2,(imag(rx_freq_data_syms(i))-3*Kmod)^2)-min((imag(rx_freq_data_syms(i))+Kmod)^2,(imag(rx_freq_data_syms(i))-Kmod)^2);
    end
    soft_bits(1:4:length(soft_bits)) = bit0 / (sigma^2);
    soft_bits(2:4:length(soft_bits)) = bit1 / (sigma^2);
    soft_bits(3:4:length(soft_bits)) = bit2 / (sigma^2);
    soft_bits(4:4:length(soft_bits)) = bit3 / (sigma^2);

   
elseif strcmp(modu_type,'64QAM')

    soft_bits = zeros(6*size(rx_freq_data_syms,1), size(rx_freq_data_syms,2));  % Each symbol consists of 6 bits
    bit0 = real(rx_freq_data_syms);
    bit3 = imag(rx_freq_data_syms);

    bit1 = 4/sqrt(42)-abs(real(rx_freq_data_syms));
    bit4 = 4/sqrt(42)-abs(imag(rx_freq_data_syms));


   for m=1:size(rx_freq_data_syms,2)
       for k=1:size(rx_freq_data_syms,1)
           if abs(4/sqrt(42)-abs(real(rx_freq_data_syms(k,m)))) <= 2/sqrt(42)  % bit is one
              bit2(k,m) = 2/sqrt(42) - abs(4/sqrt(42)-abs(real(rx_freq_data_syms(k,m))));
           elseif abs(real(rx_freq_data_syms(k,m))) <= 2/sqrt(42) % bit is zero, close to real axis
              bit2(k,m) = -2/sqrt(42) + abs(real(rx_freq_data_syms(k,m)));
           else
              bit2(k,m) = 6/sqrt(42)-abs(real(rx_freq_data_syms(k,m))); % bit is zero 
           end
      
          if abs(4/sqrt(42)-abs(imag(rx_freq_data_syms(k,m)))) <= 2/sqrt(42)  % bit is one
             bit5(k,m) = 2/sqrt(42) - abs(4/sqrt(42)-abs(imag(rx_freq_data_syms(k,m))));
          elseif abs(imag(rx_freq_data_syms(k,m))) <= 2/sqrt(42) % bit is zero, close to real axis
             bit5(k,m) = -2/sqrt(42) + abs(imag(rx_freq_data_syms(k,m)));
          else
             bit5(k,m) = 6/sqrt(42)-abs(imag(rx_freq_data_syms(k,m)));
          end
       end
   end

   soft_bits(1:6:size(soft_bits,1),:) = bit0;
   soft_bits(2:6:size(soft_bits,1),:) = bit1;
   soft_bits(3:6:size(soft_bits,1),:) = bit2;
   soft_bits(4:6:size(soft_bits,1),:) = bit3;
   soft_bits(5:6:size(soft_bits,1),:) = bit4;
   soft_bits(6:6:size(soft_bits,1),:) = bit5;

elseif strcmp(modu_type,'256QAM')
    soft_bits = zeros(8*size(rx_freq_data_syms,1), size(rx_freq_data_syms,2));  % Each symbol consists of 8 bits
    bit0 = real(rx_freq_data_syms);
    bit4 = imag(rx_freq_data_syms);

    bit1 = 8/sqrt(170)-abs(real(rx_freq_data_syms));
    bit5 = 8/sqrt(170)-abs(imag(rx_freq_data_syms));


   for m=1:size(rx_freq_data_syms,2)
       for k=1:size(rx_freq_data_syms,1)
           if abs(8/sqrt(170)-abs(real(rx_freq_data_syms(k,m)))) <= 4/sqrt(170)  % bit is one
              bit2(k,m) = 4/sqrt(170) - abs(8/sqrt(170)-abs(real(rx_freq_data_syms(k,m))));
           elseif abs(real(rx_freq_data_syms(k,m))) <= 4/sqrt(170) % bit is zero, close to real axis
              bit2(k,m) = -4/sqrt(170) + abs(real(rx_freq_data_syms(k,m)));
%            elseif abs(14/sqrt(170)-abs(real(rx_freq_data_syms(k,m)))) <= 2/sqrt(170)
           else
              bit2(k,m) = abs(14/sqrt(170)-abs(real(rx_freq_data_syms(k,m))))-2/sqrt(170);
           end;
      
          if abs(8/sqrt(170)-abs(imag(rx_freq_data_syms(k,m)))) <= 4/sqrt(170)  % bit is one
             bit6(k,m) = 4/sqrt(170) - abs(8/sqrt(170)-abs(imag(rx_freq_data_syms(k,m))));
          elseif abs(imag(rx_freq_data_syms(k,m))) <= 4/sqrt(170) % bit is zero, close to real axis
             bit6(k,m) = -4/sqrt(42) + abs(imag(rx_freq_data_syms(k,m)));
%           elseif abs(14/sqrt(170)-abs(imag(rx_freq_data_syms(k,m)))) <= 2/sqrt(170)
          else
             bit6(k,m) = abs(14/sqrt(170)-abs(imag(rx_freq_data_syms(k,m))))-2/sqrt(170);
          end;
          
          if abs(real(rx_freq_data_syms(k,m))) <= 2/sqrt(170) 
              bit3(k,m) = -2/sqrt(170) + abs(real(rx_freq_data_syms(k,m)));
          elseif   abs(4/sqrt(170)-abs(real(rx_freq_data_syms(k,m)))) <= 2/sqrt(170) 
              bit3(k,m) = 2/sqrt(170) - abs(4/sqrt(170)-abs(real(rx_freq_data_syms(k,m))));
          elseif   abs(8/sqrt(170)-abs(real(rx_freq_data_syms(k,m)))) <= 2/sqrt(170) 
              bit3(k,m) = abs(8/sqrt(170)-abs(real(rx_freq_data_syms(k,m))))-2/sqrt(170);
          elseif abs(12/sqrt(170)-abs(real(rx_freq_data_syms(k,m)))) <= 2/sqrt(170) 
              bit3(k,m) = 2/sqrt(170)-abs(12/sqrt(170)-abs(real(rx_freq_data_syms(k,m))));
          else
              bit3(k,m) = 14/sqrt(170) - abs(real(rx_freq_data_syms(k,m)));
          end;
          
          if abs(imag(rx_freq_data_syms(k,m))) <= 2/sqrt(170) 
              bit7(k,m) = -2/sqrt(170) + abs(imag(rx_freq_data_syms(k,m)));
          elseif   abs(4/sqrt(170)-abs(imag(rx_freq_data_syms(k,m)))) <= 2/sqrt(170) 
              bit7(k,m) = 2/sqrt(170) - abs(4/sqrt(170)-abs(imag(rx_freq_data_syms(k,m))));
          elseif   abs(8/sqrt(170)-abs(imag(rx_freq_data_syms(k,m)))) <= 2/sqrt(170) 
              bit7(k,m) = abs(8/sqrt(170)-abs(imag(rx_freq_data_syms(k,m))))-2/sqrt(170);
          elseif abs(12/sqrt(170)-abs(imag(rx_freq_data_syms(k,m)))) <= 2/sqrt(170) 
              bit7(k,m) = 2/sqrt(170)-abs(12/sqrt(170)-abs(imag(rx_freq_data_syms(k,m))));
          else 
              bit7(k,m) = 14/sqrt(170) - abs(imag(rx_freq_data_syms(k,m)));
          end;
          
       end;
  end;

   soft_bits(1:8:size(soft_bits,1),:) = bit0;
   soft_bits(2:8:size(soft_bits,1),:) = bit1;
   soft_bits(3:8:size(soft_bits,1),:) = bit2;
   soft_bits(4:8:size(soft_bits,1),:) = bit3;
   soft_bits(5:8:size(soft_bits,1),:) = bit4;
   soft_bits(6:8:size(soft_bits,1),:) = bit5;
   soft_bits(7:8:size(soft_bits,1),:) = bit6;
   soft_bits(8:8:size(soft_bits,1),:) = bit7;
else
   error('Undefined modulation');
end


% soft_bits = soft_bits(:)'; %���õ���6760��ʵ��ת��Ϊ6760�С�
end
