
import numpy as np
import numpy.linalg as la
from .utils import _QPSK_Constellation, _16QAM_Constellation, _64QAM_Constellation
from scipy.linalg import cholesky, sqrtm
from numba import jit


# @jit()
def mhgd():  # todo

    return


def nag_mcmc():  # todo

    return

